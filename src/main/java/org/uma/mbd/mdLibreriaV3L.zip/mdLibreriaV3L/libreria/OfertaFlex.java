package org.uma.mbd.mdLibreriaV3L.libreria;

public interface OfertaFlex {
    double getDescuento(Libro libro);
}
